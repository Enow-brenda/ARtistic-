<?php

$conn = mysqli_connect("localhost","root","","artistic");


if(!$conn){
    die('Connection Failed'. mysqli_connect_error());
}

?>
<script src="delete.js"></script>