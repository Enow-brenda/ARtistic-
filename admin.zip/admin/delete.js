function showSweetAlert(){
    var secret=window.prompt("Enter Your Secret KEY")
    var pass=window.prompt("Enter Your Password")
}